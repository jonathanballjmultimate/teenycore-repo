#!/bin/sh
# point the ELF interpreter for the bundled binaries at the package's libs
R=${TEENYCORE_ROOT:-/}
mkdir -p "$R/lib64" "$R/usr/bin"
if [ ! -e "$R/lib64/ld-linux-x86-64.so.2" ]; then
  ln -sf "$R/opt/teenycore-gui/lib/ld-linux-x86-64.so.2" "$R/lib64/ld-linux-x86-64.so.2"
fi
ln -sfn "$R/opt/teenycore-gui/bin/xkbcomp" "$R/usr/bin/xkbcomp"
